## Rules

### User

- Can create a user using the cpf and name

### Cashback

- Can receive points based on the order (total, subTotal, or other value) and category
- Can transfer points to other user
- Cannot transter points if the value to be transfered is more than the current value of the user balance
- Can get the extract
- Can spend cashback
- Cannot spend cashback if the balance is less than cashback spent
