export class Cashback {
  value: number;

  constructor(value: number) {
    this.value = value;
  }
}
