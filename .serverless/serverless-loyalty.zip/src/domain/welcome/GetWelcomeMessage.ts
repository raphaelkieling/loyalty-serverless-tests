export interface GetWelcomeMessage {
  handle(): string;
}
